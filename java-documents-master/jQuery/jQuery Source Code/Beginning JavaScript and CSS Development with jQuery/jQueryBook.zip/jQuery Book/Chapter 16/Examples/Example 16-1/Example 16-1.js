$(document).ready(
  function() {
    $('div#tmpTabExample > ul').tabs();
  }
);