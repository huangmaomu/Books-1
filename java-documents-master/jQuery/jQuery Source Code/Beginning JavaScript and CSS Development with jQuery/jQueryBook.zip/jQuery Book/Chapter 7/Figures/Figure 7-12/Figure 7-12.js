var hFinder = {
  onFileUpload : function()
  {
    alert('File uploaded!');
  }
};