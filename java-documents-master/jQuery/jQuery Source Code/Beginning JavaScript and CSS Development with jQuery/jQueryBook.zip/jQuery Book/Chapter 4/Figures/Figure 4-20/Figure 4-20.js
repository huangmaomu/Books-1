$(document).ready(
  function() {
    $('p').wrapAll(document.createElement('div'));
  }
);