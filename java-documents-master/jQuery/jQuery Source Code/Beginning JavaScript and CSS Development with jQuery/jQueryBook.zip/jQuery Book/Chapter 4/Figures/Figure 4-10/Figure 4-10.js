$(document).ready(
  function() {
    $('table tbody').append(
      "<tr>\n" +
      "  <td>Double Fantasy</td>\n" +
      "  <td>1980</td>\n" +
      "</tr>\n"
    );
  }
);