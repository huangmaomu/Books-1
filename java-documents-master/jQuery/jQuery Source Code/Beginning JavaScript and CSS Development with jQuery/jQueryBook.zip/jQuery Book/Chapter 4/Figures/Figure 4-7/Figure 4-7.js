$(document).ready(
  function() {
    $('p#tmpQuote-1').text(      
      "Getting older is no problem. You just have to " + 
      "live long enough. <i>- Groucho Marx</i>"
    );

    $('p#tmpQuote-2').html(
      "I have had a perfectly wonderful evening, but " + 
      "this wasn't it. <i>- Groucho Marx</i>"
    );
  }
);