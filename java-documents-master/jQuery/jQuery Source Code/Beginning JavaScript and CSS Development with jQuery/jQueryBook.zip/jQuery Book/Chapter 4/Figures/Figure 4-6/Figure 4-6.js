$(document).ready(
  function() {
   alert(
     'HTML: ' + $('p').html() + "\n" +
     'Text: ' + $('p').text()
   )
  }
);