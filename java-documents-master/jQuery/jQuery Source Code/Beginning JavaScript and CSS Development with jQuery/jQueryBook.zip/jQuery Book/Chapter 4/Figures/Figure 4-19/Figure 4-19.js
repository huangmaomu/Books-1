$(document).ready(
  function() {
    $('p').wrapInner('<i></i>');
  }
);