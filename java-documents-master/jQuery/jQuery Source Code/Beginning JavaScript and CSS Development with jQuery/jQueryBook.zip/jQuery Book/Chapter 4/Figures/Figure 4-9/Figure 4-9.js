$(document).ready(
  function() {
    $('table tbody')[0].innerHTML += 
        "<tr>\n" +
        "  <td>Double Fantasy</td>\n" +
        "  <td>1980</td>\n" +
        "</tr>\n";
  }
);