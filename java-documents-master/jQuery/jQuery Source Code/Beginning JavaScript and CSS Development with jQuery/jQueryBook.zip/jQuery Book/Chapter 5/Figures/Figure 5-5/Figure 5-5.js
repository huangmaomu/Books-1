$(document).ready(
  function() {
    $('li').each(
      function() {
        $(this).addClass('tmpSong');
      }
    );
  }
);