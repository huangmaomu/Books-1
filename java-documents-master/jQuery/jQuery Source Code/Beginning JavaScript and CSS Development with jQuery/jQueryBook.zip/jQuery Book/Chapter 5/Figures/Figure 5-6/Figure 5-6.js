$(document).ready(
  function() {
    $('li')
      .filter('.George')
      .addClass('tmpSelected');
  }
);