$(document).ready(
  function() {
    $('div#tmpExample').dialog({
      modal: true,
      overlay : {
        background: '#fff',
        opacity: '0.7'
      }
    });
  }
);