$(document).ready(
  function() {
    $('div#tmpExample').dialog({
      resizable: false,
      draggable: false
    });
  }
);