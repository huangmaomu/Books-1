$(document).ready(
  function() {
    $('div#tmpExample').dialog();
  }
);