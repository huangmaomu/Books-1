$(document).ready(
  function() {
    alert(
      'outerWidth: '  + $('div').outerWidth({margin: true}) + "\n" + 
      'outerHeight: ' + $('div').outerHeight({margin: true})
    );
  }
);