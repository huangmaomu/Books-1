$(document).ready(
  function() {
    alert(
      'outerWidth: '  + $('div').outerWidth() + "\n" + 
      'outerHeight: ' + $('div').outerHeight()
    );
  }
);