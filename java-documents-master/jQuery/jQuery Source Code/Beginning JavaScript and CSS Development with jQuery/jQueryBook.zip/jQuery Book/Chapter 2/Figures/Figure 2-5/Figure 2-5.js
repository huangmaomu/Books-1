var tmpExample = {
  ready : function() {
    $('ul#tmpPlaces li.tmpExampleCity').siblings('.tmpRealmOfMen').addClass('tmpSiblings');
  }
};

$(document).ready(tmpExample.ready);