var tmpExample = {
  ready : function() {
    $('ul#tmpFavorites').find('li').addClass('tmpFound');
  }
};

$(document).ready(tmpExample.ready);