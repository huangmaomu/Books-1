$(document).ready(
  function() {
    $('ul').sortable();
  }
);