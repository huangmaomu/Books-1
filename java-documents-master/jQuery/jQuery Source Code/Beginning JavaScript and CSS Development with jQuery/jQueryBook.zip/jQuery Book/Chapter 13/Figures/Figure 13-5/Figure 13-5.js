$(document).ready(
  function() {
    $('ul').accordion({
      autoHeight: false,
      active: false,
      alwaysOpen: false
    });
  }
);