$(document).ready(
  function() {
    $('ul').accordion({
      fillSpace: true,
      event: 'mouseover',
      active: 'a.tmpSelected',
      
    });
  }
);