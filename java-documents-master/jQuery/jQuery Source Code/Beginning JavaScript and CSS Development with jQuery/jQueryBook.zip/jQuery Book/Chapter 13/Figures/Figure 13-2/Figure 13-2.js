$(document).ready(
  function() {
    $('ul').accordion({
      autoHeight: false   
    });
  }
);