$(document).ready(
  function() {
    $('ul').accordion();
  }
);