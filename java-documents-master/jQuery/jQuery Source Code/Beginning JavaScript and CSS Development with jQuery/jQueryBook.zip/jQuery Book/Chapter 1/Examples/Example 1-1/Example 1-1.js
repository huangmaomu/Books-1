if ($) {
  $(document).ready(
    function() {
      $('p').addClass('tmpFrameworkLoaded');
      $('p').text('jQuery successfully loaded and running!');
    }
  );
}