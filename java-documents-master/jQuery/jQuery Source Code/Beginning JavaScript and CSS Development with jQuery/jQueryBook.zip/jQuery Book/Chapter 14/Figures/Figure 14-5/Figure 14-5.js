$(document).ready(
  function() {
    $('input#tmpDate').datepicker({
        rangeSelect: true
    });
  }
);