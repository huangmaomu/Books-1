$(document).ready(
  function() {
    $('input#tmpDate').datepicker({
        dateFormat: 'dd/mm/yy',
        firstDay: 1
    });
  }
);