$(document).ready(
  function() {
    $('input#tmpDate').datepicker();
  }
);