{
	"books":[
		{
		"title": "I'm a Stranger Here Myself: Notes on Returning to America After 20 Years Away", 
		"author": "Bill Bryson",
		"category": "Travel",
		"pubdate": "06/2000",
		"isbn": "0767903820"
		},
		{
		"title": "Open: An Autobiography", 
		"author": "Andre Agassi",
		"category": "Biography",
		"pubdate": "11/2009",
		"isbn": "0307268198"
		},
		{
		"title": "The Art of the Start: The Time-Tested, Battle-Hardened Guide for Anyone Starting Anything", 
		"author": "Guy Kawasaki",
		"category": "Business",
		"pubdate":"09/2004",
		"isbn": "1591840565"
		},
		{
		"title": "Founders at Work: Stories of Startups' Early Days", 
		"author": "Jessica Livingston",
		"category": "Business",
		"pubdate": "09/2009",
		"isbn": "1430210788"
		},
		{
		"title": "Getting Real: The smarter, faster, easier way to build a successful web application", 
		"author": "Jason Fried",
		"category": "Business",
		"pubdate": "09/2009",
		"isbn": "0578012810"
		}
	]
}
