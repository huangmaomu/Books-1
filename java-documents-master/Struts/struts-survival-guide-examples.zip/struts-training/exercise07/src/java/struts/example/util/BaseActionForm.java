package struts.example.util;

import org.apache.struts.action.ActionForm;

public abstract class BaseActionForm extends ActionForm
{
	
}