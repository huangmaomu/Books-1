package coreservlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages Volume II
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://volume2.coreservlets.com/.
 *  (C) 2007 Marty Hall, Larry Brown, and Yaakov Chaikin;
 *  may be freely used or adapted.
 */
public class RecordPlaces extends HttpServlet {
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException {
//    NameBean[] topThree =
//      { new NameBean(request.getParameter("first1"),
//                     request.getParameter("last1")),
//        new NameBean(request.getParameter("first2"),
//                     request.getParameter("last2")),
//        new NameBean(request.getParameter("first3"),
//                     request.getParameter("last3")) };
//    recordResultsInDatabase(topThree);
//    request.setAttribute("topThree", topThree);
//    String address = "/WEB-INF/results/show-top-three.jsp";
//    RequestDispatcher dispatcher =
//      request.getRequestDispatcher(address);
//    dispatcher.forward(request, response);
  }
//
//  public void recordResultsInDatabase(NameBean[] names) {
//    // Omitted
//  }
}
