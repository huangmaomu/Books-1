package coreservlets;

import javax.servlet.*;
import java.util.*;

/** Simple listener that prints a report on the standard output 
 *  when the ServletContext is created or destroyed.
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages Volume II
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://volume2.coreservlets.com/.
 *  (C) 2007 Marty Hall, Larry Brown, and Yaakov Chaikin;
 *  may be freely used or adapted.
 */

public class ContextReporter implements ServletContextListener {
  public void contextInitialized(ServletContextEvent event) {
    System.out.println("Context created on " +
                       new Date() + ".");
  }

  public void contextDestroyed(ServletContextEvent event) {
    System.out.println("Context destroyed on " +
                       new Date() + ".");
  }
}
