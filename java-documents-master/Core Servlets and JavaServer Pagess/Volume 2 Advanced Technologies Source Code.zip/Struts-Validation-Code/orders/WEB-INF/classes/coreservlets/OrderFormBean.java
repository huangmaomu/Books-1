package coreservlets;

import org.apache.struts.validator.*;

/** Simple bean holding order information.
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages Volume II
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://volume2.coreservlets.com/.
 *  (C) 2007 Marty Hall, Larry Brown, and Yaakov Chaikin;
 *  may be freely used or adapted.
 */

public class OrderFormBean extends ValidatorForm {
  private String firstName = "";
  private String lastName = "";
  private String address = "";
  private String zipCode = "";
  private String creditCardNumber = "";
  private String email = "";

  public String getFirstName() {
    return(firstName);
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return(lastName);
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getAddress() {
    return(address);
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getZipCode() {
    return(zipCode);
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public String getCreditCardNumber() {
    return(creditCardNumber);
  }

  public void setCreditCardNumber(String creditCardNumber) {
    this.creditCardNumber = creditCardNumber;
  }

  public String getEmail() {
    return(email);
  }

  public void setEmail(String email) {
    this.email = email;
  }
}
